#include <stdio.h>
#include <stdlib.h>

void usage(){
  printf("Usage : ./question0 nombre1 nombre2 operateur\n");
  printf("\t operateur : +, -, x , /\n");
}

double plus(double a, double b){ return a+b;}
double minus(double a, double b) { return a-b;}
double multiply(double a, double b) { return a*b;}
double divide(double a, double b) {
  if(b != 0.0){
    return a / b;
  } else {
    return 0;
  }
}

void switch_op(double a, double b, char op_code){
  double result;
  int ok = 1;

  switch(op_code){
  case '+' : result = plus(a, b); break;
  case '-' : result = minus(a, b); break;
  case 'x' : result = multiply(a, b); break;
  case '/' : result = divide(a, b); break;
  default : ok = 0;
  }
	
  if(ok == 1)
    printf("%lf\t%c\t%lf\t=\t%lf\n",a,op_code,b,result);
}

int main(int argc, char* argv[]){

  double nb1, nb2;
  char op;

  if(argc != 4){
    usage();
    return -1;
  }

  nb1 = atof(argv[1]);
  nb2 = atof(argv[2]);
  op = argv[3][0]; 
	
  switch_op(nb1,nb2,op);
	
  return 0;
}
