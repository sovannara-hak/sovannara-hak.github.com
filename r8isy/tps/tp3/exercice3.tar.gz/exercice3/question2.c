#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "image.h"
#include "transf_image.h"

void display_usage(){
    printf("\nUsage : ./question2 --bruit nom_fichier_destination pourcentage nom_fichier_origine\n\n");
}

int main(int argc, char **argv){

    image_t *src = NULL;
    image_t *dest = NULL;
    unsigned long t0, tf;
    unsigned int pcent;

    /* Test des arguments du main */
    if((argc != 5) || strcmp(argv[1],"--bruit")){
        display_usage();
        return -1;
    }
    
    pcent = atoi(argv[3]);
    if((pcent > 100) || (pcent < 0)){
        display_usage();
        return -1;
    }
    
    /* Chargement de l'image d'origine */
    src = charger_image_pgm(argv[4]);
    if(! src){
        display_usage();
        return -1;
    }

    /* Compteur de temps initial */    
    t0 = get_time();

    /* Appel de la fonction de bruitage */
    /* ????? */

    /* Compteur de temps final */
    tf = get_time();
    printf("Operation realisee en %lu microsecondes.\n",(tf-t0));

    if(! dest)
        return -1;
      
    /* Sauvegarde de l'image */
    sauver_image_pgm(argv[2],dest);

    /* Destruction des images en local */
    detruire_image(src);
    detruire_image(dest);
    
    return 0;
}
