#ifndef TRANSF_IMAGE
#define TRANSF_IMAGE

#include "image.h"

image_t *bruiter_image(image_t *src, unsigned int pourcent);

unsigned long get_time();
#endif
