#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "image.h"

image_t *creer_image(){

  image_t *p = (image_t *) malloc(sizeof(image_t));
  
  p->nx=0;
  p->ny=0;
  p->nb_ng=0;
  p->buff=NULL;
  
  return p;
}

image_t *allouer_image(image_t *p_im,
		       unsigned int nx, 
		       unsigned int ny,
		       unsigned int nb_ng){

  p_im->nx = nx;
  p_im->ny = ny;
  p_im->nb_ng = nb_ng;
  p_im->buff= (unsigned char *) calloc(nx * ny, sizeof(char));

  return p_im;
}

image_t *copier_image(image_t *src){

  image_t *dst = creer_image();

  dst->nx = src->nx;
  dst->ny = src->ny;
  dst->nb_ng = src->nb_ng;
  dst->buff = (unsigned char *) malloc(src->nx * src->ny);
  memcpy(dst->buff, src->buff, src->nx * src->ny);
	return dst;
}

void detruire_image(image_t *p){
  
  free(p->buff);
  free(p);
}



#define TMP_STR_SIZE 64

image_t *charger_image_pgm(char *nom_fichier){
  FILE *f;
  image_t *img;
  char tmp_str[TMP_STR_SIZE];
  
  f=fopen(nom_fichier, "r");
  
  if (!f)
    {
      fprintf(stderr, "impossible d'ouvrir le fichier %s\n", nom_fichier);
      return NULL;
    }
  
  if (!(img = creer_image()))
    return NULL;
  
  
  fgets(tmp_str, TMP_STR_SIZE, f);
  
  if (strcmp(tmp_str, "P5\n"))
    {
      fprintf(stderr, "format fichier non pgm (P5)\n");
      return NULL;
    }
  
  fgets(tmp_str, TMP_STR_SIZE, f);
  
  if (sscanf(tmp_str, "%d %d\n", &(img->nx), &(img->ny)) != 2)
    {
      fprintf(stderr, "format fichier non pgm\n");
      return NULL;
    }

  fgets(tmp_str, TMP_STR_SIZE, f);
  
  if (sscanf(tmp_str, "%d\n", &(img->nb_ng)) != 1)
    {
      fprintf(stderr, "format fichier non pgm\n");
      return NULL;
    }
  
	img->buff = (unsigned char *) malloc(img->nx * img->ny);
	
	if (fread(img->buff, img->nx, img->ny, f) != img->ny)
	  {
	    fprintf(stderr, "fichier image imcomplet!\n");
	    return NULL;
	  }
	fclose(f);
	return img;
}

int sauver_image_pgm(char *nom_fichier, image_t *img){
  FILE *f;
  
  f=fopen(nom_fichier, "w");
  
  if (!f)
    {
      fprintf(stderr, "impossible d'ouvrir le fichier %s\n", nom_fichier);
      return 0;
    }
  
  fprintf(f, "P5\n");
  fprintf(f, "%d %d\n", img->nx, img->ny);
  fprintf(f, "%d\n", img->nb_ng);
  
  fwrite(img->buff, img->nx, img->ny, f);
  fclose(f);
  return 1;
}
